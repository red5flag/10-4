#!/bin/bash
set -euo pipefail

# Pi-Kiosk install script for pre-built binaries
# Use this on the Pi with the dist archive (no Rust toolchain needed)
#
# Usage:  sudo ./install.sh

INSTALL_PREFIX="${INSTALL_PREFIX:-/usr/local}"
SERVICE_DIR="${SERVICE_DIR:-/etc/systemd/system}"
DATA_DIR="${DATA_DIR:-/var/lib/pi-kiosk}"
CONFIG_DIR="${CONFIG_DIR:-/etc/pi-kiosk}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Must be root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run as root (use sudo)"
    exit 1
fi

echo "=== Pi-Kiosk Install ==="

# Create user if it doesn't exist
if ! id "pikiosk" &>/dev/null; then
    echo "Creating pikiosk user…"
    useradd --system --no-create-home --shell /usr/sbin/nologin pikiosk
fi

# Add to hardware access groups
usermod -aG dialout pikiosk 2>/dev/null || true
usermod -aG audio pikiosk 2>/dev/null || true
usermod -aG i2c pikiosk 2>/dev/null || true
usermod -aG gpio pikiosk 2>/dev/null || true

# Create directories
echo "Creating directories…"
mkdir -p "$DATA_DIR/clips"
mkdir -p "$DATA_DIR/backups"
mkdir -p "$CONFIG_DIR/vpn"
mkdir -p "$CONFIG_DIR/tor"
mkdir -p "$CONFIG_DIR/tls"

# Install pre-built binaries (from dist archive)
echo "Installing binaries…"
if [ -f "$SCRIPT_DIR/pi-kiosk-web" ]; then
    install -m 755 "$SCRIPT_DIR/pi-kiosk-web" "$INSTALL_PREFIX/bin/pi-kiosk-web"
    install -m 755 "$SCRIPT_DIR/pi-kiosk-priv" "$INSTALL_PREFIX/bin/pi-kiosk-priv"
elif [ -f "$SCRIPT_DIR/target/release/pi-kiosk-web" ]; then
    install -m 755 "$SCRIPT_DIR/target/release/pi-kiosk-web" "$INSTALL_PREFIX/bin/pi-kiosk-web"
    install -m 755 "$SCRIPT_DIR/target/release/pi-kiosk-priv" "$INSTALL_PREFIX/bin/pi-kiosk-priv"
else
    echo "ERROR: Pre-built binaries not found in $SCRIPT_DIR"
    echo "Expected: pi-kiosk-web and pi-kiosk-priv next to this script"
    exit 1
fi

# Install systemd units
echo "Installing systemd units…"
if [ -d "$SCRIPT_DIR/systemd" ]; then
    install -m 644 "$SCRIPT_DIR/systemd/pi-kiosk-web.service" "$SERVICE_DIR/pi-kiosk-web.service"
    install -m 644 "$SCRIPT_DIR/systemd/pi-kiosk-priv.service" "$SERVICE_DIR/pi-kiosk-priv.service"
    install -m 644 "$SCRIPT_DIR/systemd/kiosk-browser.service" "$SERVICE_DIR/kiosk-browser.service" 2>/dev/null || true
elif [ -d "$SCRIPT_DIR/../systemd" ]; then
    install -m 644 "$SCRIPT_DIR/../systemd/pi-kiosk-web.service" "$SERVICE_DIR/pi-kiosk-web.service"
    install -m 644 "$SCRIPT_DIR/../systemd/pi-kiosk-priv.service" "$SERVICE_DIR/pi-kiosk-priv.service"
    install -m 644 "$SCRIPT_DIR/../systemd/kiosk-browser.service" "$SERVICE_DIR/kiosk-browser.service" 2>/dev/null || true
else
    echo "WARNING: systemd unit files not found, skipping"
fi

# Install udev rules
echo "Installing udev rules…"
if [ -f "$SCRIPT_DIR/99-pi-kiosk-modem.rules" ]; then
    install -m 644 "$SCRIPT_DIR/99-pi-kiosk-modem.rules" /etc/udev/rules.d/99-pi-kiosk-modem.rules
elif [ -f "$SCRIPT_DIR/../udev/99-pi-kiosk-modem.rules" ]; then
    install -m 644 "$SCRIPT_DIR/../udev/99-pi-kiosk-modem.rules" /etc/udev/rules.d/99-pi-kiosk-modem.rules
fi
udevadm trigger --subsystem-match=tty --subsystem-match=usb 2>/dev/null || true
udevadm trigger --subsystem-match=sound 2>/dev/null || true

# Apply database migration
echo "Applying database migration…"
if [ -f "$SCRIPT_DIR/001_init.sql" ]; then
    sqlite3 "$DATA_DIR/kiosk.db" < "$SCRIPT_DIR/001_init.sql"
elif [ -f "$SCRIPT_DIR/../migrations/001_init.sql" ]; then
    sqlite3 "$DATA_DIR/kiosk.db" < "$SCRIPT_DIR/../migrations/001_init.sql"
fi

# Merge boot config fragments
if [ -f "$SCRIPT_DIR/config.txt" ]; then
    echo "Merging boot config fragments…"
    cat "$SCRIPT_DIR/config.txt" >> /boot/config.txt
elif [ -f "$SCRIPT_DIR/../config/config.txt" ]; then
    echo "Merging boot config fragments…"
    cat "$SCRIPT_DIR/../config/config.txt" >> /boot/config.txt
fi

# Set ownership
echo "Setting ownership…"
chown -R pikiosk:pikiosk "$DATA_DIR"
chown -R root:root "$CONFIG_DIR"

# Enable services
echo "Enabling services…"
systemctl daemon-reload
systemctl enable pi-kiosk-priv.service
systemctl enable pi-kiosk-web.service

echo ""
echo "=== Install complete ==="
echo ""
echo "Start the services:"
echo "  sudo systemctl start pi-kiosk-priv pi-kiosk-web"
echo ""
echo "View the dashboard:"
echo "  http://localhost:3000          (on the Pi)"
echo "  http://$(hostname -I 2>/dev/null | awk '{print $1}'):3000   (from another device)"
echo ""
echo "Enable fullscreen kiosk browser (requires chromium-browser):"
echo "  sudo apt install chromium-browser"
echo "  sudo systemctl enable kiosk-browser.service"
echo "  sudo systemctl start kiosk-browser.service"
echo ""
echo "Data directory: $DATA_DIR"
echo "Config directory: $CONFIG_DIR"
